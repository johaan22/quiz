const questionLabel = document.getElementById("question-label");
const questionText = document.getElementById("question-text");
const answersDiv = document.getElementById("answers");
const result = document.getElementById("result");
const nextBtn = document.getElementById("next-btn");
const questionCard = document.getElementById("question-card");
const emptyMsg = document.getElementById("empty-msg");
const progressEl = document.getElementById("progress");
const progressText = document.getElementById("progress-text");
const scoreText = document.getElementById("score-text");
const summaryCard = document.getElementById("summary-card");
const summaryText = document.getElementById("summary-text");
const tryAgainBtn = document.getElementById("try-again-btn");
const categorySelect = document.getElementById("filter-category");

let questions = [];
let currentIndex = 0;
let score = 0;
let answered = false;

nextBtn.addEventListener("click", handleNext);
tryAgainBtn.addEventListener("click", startQuiz);
categorySelect.addEventListener("focus", refreshCategoryOptions);
refreshCategoryOptions();

// Read the current filter selections and turn them into a /question query
// string. Empty values mean "no filter" — i.e. the server sends back every
// question for that dimension.
function currentFilters() {
  const params = new URLSearchParams();
  if (categorySelect.value) params.set("category", categorySelect.value);
  const diff = document.querySelector(
    'input[name="filter-difficulty"]:checked',
  );
  if (diff && diff.value) params.set("difficulty", diff.value);
  return params.toString();
}

// Refresh the category <select> options from the server. Called on load and
// whenever the user opens the dropdown, so the list always reflects what's in
// the database (the system of record).
async function refreshCategoryOptions() {
  try {
    const categories = await fetchCategories();
    const names = uniqueCategoryNames(categories);
    const current = categorySelect.value;
    categorySelect.innerHTML =
      `<option value="">Any category</option>` +
      names.map((n) => `<option value="${n}">${n}</option>`).join("");
    if (current && names.includes(current)) categorySelect.value = current;
  } catch (err) {
    console.warn("Could not load categories:", err.message);
  }
}

// "Next" means: start the quiz on first press, then step through the batch we
// already fetched. When we run off the end, show the summary instead.
async function handleNext() {
  if (questions.length === 0) {
    await startQuiz();
    return;
  }

  currentIndex++;
  if (currentIndex >= questions.length) {
    showSummary();
  } else {
    showQuestion();
  }
}

// Fetch all questions matching the current category/difficulty filters and
// start a fresh round. Called when the user clicks Start Quiz or Try Again.
async function startQuiz() {
  emptyMsg.textContent = "Loading...";
  emptyMsg.classList.remove("hidden");
  questionCard.classList.add("hidden");
  summaryCard.classList.add("hidden");
  progressEl.classList.add("hidden");
  nextBtn.classList.remove("hidden");
  nextBtn.disabled = true;
  tryAgainBtn.disabled = true;

  questions = [];
  currentIndex = 0;
  score = 0;

  try {
    const qs = currentFilters();
    const res = await fetch(`/question${qs ? `?${qs}` : ""}`);
    if (res.status === 404) {
      emptyMsg.textContent =
        "No questions match these filters — try changing them, or go create some.";
      nextBtn.textContent = "Start Quiz";
      nextBtn.disabled = false;
      tryAgainBtn.disabled = false;
      return;
    }
    const data = await res.json();
    questions = Array.isArray(data.questions) ? data.questions : [];
  } catch {
    emptyMsg.textContent = "Could not reach the server.";
    nextBtn.disabled = false;
    tryAgainBtn.disabled = false;
    return;
  }

  tryAgainBtn.disabled = false;

  if (questions.length === 0) {
    emptyMsg.textContent = "No questions returned by the server.";
    nextBtn.disabled = false;
    return;
  }

  showQuestion();
}

function showQuestion() {
  const q = questions[currentIndex];
  answered = false;
  result.classList.add("hidden");
  answersDiv.innerHTML = "";
  emptyMsg.textContent = "";
  emptyMsg.classList.add("hidden");

  // "Easy question on Sport" — anchors the user to the category/difficulty
  // of the question they're currently looking at.
  const difficultyLabel =
    q.difficulty.charAt(0).toUpperCase() + q.difficulty.slice(1);
  questionLabel.textContent = `${difficultyLabel} question on ${q.category}`;

  questionText.textContent = q.question;
  q.answers.forEach((text) => {
    const btn = document.createElement("button");
    btn.className = "answer-btn";
    btn.textContent = text;
    btn.addEventListener("click", () => selectAnswer(text, q.correctAnswer));
    answersDiv.appendChild(btn);
  });

  progressEl.classList.remove("hidden");
  updateProgress();

  summaryCard.classList.add("hidden");
  questionCard.classList.remove("hidden");
  nextBtn.classList.remove("hidden");
  nextBtn.disabled = true;
  nextBtn.textContent =
    currentIndex === questions.length - 1 ? "Finish" : "Next Question";
}

function selectAnswer(selected, correctAnswer) {
  if (answered) return;
  answered = true;

  const buttons = answersDiv.querySelectorAll(".answer-btn");
  buttons.forEach((btn) => {
    btn.disabled = true;
    if (btn.textContent === correctAnswer) btn.classList.add("correct");
    if (btn.textContent === selected && selected !== correctAnswer) {
      btn.classList.add("wrong");
    }
  });

  if (selected === correctAnswer) {
    score++;
    result.textContent = "Correct!";
    result.className = "result correct-text";
  } else {
    result.textContent = `Wrong — the correct answer was "${correctAnswer}".`;
    result.className = "result wrong-text";
  }
  result.classList.remove("hidden");
  nextBtn.disabled = false;
  updateProgress();
}

function updateProgress() {
  const total = questions.length;
  progressText.textContent = `Question ${currentIndex + 1} of ${total}`;
  scoreText.textContent = `Score: ${score}`;
}

function showSummary() {
  questionCard.classList.add("hidden");
  nextBtn.classList.add("hidden");
  progressEl.classList.add("hidden");

  const total = questions.length;
  const percentage = total === 0 ? 0 : Math.round((score / total) * 100);
  summaryText.textContent = `You scored ${score} out of ${total} (${percentage}%)`;
  summaryCard.classList.remove("hidden");
}
