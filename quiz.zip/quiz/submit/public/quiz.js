const questionText = document.getElementById("question-text");
const answersDiv = document.getElementById("answers");
const result = document.getElementById("result");
const nextBtn = document.getElementById("next-btn");
const questionCard = document.getElementById("question-card");
const emptyMsg = document.getElementById("empty-msg");
const progressEl = document.getElementById("progress");
const progressText = document.getElementById("progress-text");
const scoreText = document.getElementById("score-text");
const progressBarWrap = document.getElementById("progress-bar-wrap");
const progressBar = document.getElementById("progress-bar");
const summaryCard = document.getElementById("summary-card");
const summaryText = document.getElementById("summary-text");
const tryAgainBtn = document.getElementById("try-again-btn");

let allQuestions = [];
let currentIndex = 0;
let score = 0;
let answered = false;

nextBtn.addEventListener("click", handleNext);
tryAgainBtn.addEventListener("click", resetQuiz);

async function handleNext() {
  if (allQuestions.length === 0) {
    await fetchQuestions();
    if (allQuestions.length === 0) return;
    showQuestion();
    return;
  }

  currentIndex++;
  if (currentIndex >= allQuestions.length) {
    showSummary();
  } else {
    showQuestion();
  }
}

async function fetchQuestions() {
  emptyMsg.textContent = "Loading...";
  try {
    const res = await fetch("/question");
    if (res.status === 404) {
      emptyMsg.textContent = "No questions yet — go create some first!";
      return;
    }
    const data = await res.json();
    allQuestions = data.questions;
    currentIndex = 0;
    score = 0;
  } catch {
    emptyMsg.textContent = "Could not reach the server.";
  }
}

function showQuestion() {
  const q = allQuestions[currentIndex];
  answered = false;
  result.classList.add("hidden");
  answersDiv.innerHTML = "";
  emptyMsg.textContent = "";

  progressEl.classList.remove("hidden");
  progressBarWrap.classList.remove("hidden");
  updateProgress();

  questionText.textContent = q.question;
  q.answers.forEach((text) => {
    const btn = document.createElement("button");
    btn.className = "answer-btn";
    btn.textContent = text;
    btn.addEventListener("click", () => selectAnswer(text, q.correctAnswer));
    answersDiv.appendChild(btn);
  });

  summaryCard.classList.add("hidden");
  questionCard.classList.remove("hidden");
  nextBtn.classList.remove("hidden");
  nextBtn.disabled = true;
  nextBtn.textContent =
    currentIndex === allQuestions.length - 1 ? "Finish" : "Next Question";
}

function selectAnswer(selected, correctAnswer) {
  if (answered) return;
  answered = true;

  const buttons = answersDiv.querySelectorAll(".answer-btn");
  buttons.forEach((btn) => {
    btn.disabled = true;
    if (btn.textContent === correctAnswer) btn.classList.add("correct");
    if (btn.textContent === selected && selected !== correctAnswer) {
      btn.classList.add("wrong");
    }
  });

  if (selected === correctAnswer) {
    score++;
    result.textContent = "Correct! 😄";
    result.className = "result correct-text";
  } else {
    result.textContent = "Wrong answer 😔";
    result.className = "result wrong-text";
  }
  result.classList.remove("hidden");
  nextBtn.disabled = false;
  updateProgress();
}

function updateProgress() {
  const total = allQuestions.length;
  progressText.textContent = `Question ${currentIndex + 1} of ${total}`;
  scoreText.textContent = `Score: ${score}`;
  const pct = ((currentIndex + (answered ? 1 : 0)) / total) * 100;
  progressBar.style.width = `${pct}%`;
}

function showSummary() {
  questionCard.classList.add("hidden");
  nextBtn.classList.add("hidden");
  progressEl.classList.add("hidden");
  progressBar.style.width = "100%";

  const total = allQuestions.length;
  const percentage = Math.round((score / total) * 100);
  summaryText.textContent = `You scored ${score} out of ${total} (${percentage}%)`;
  summaryCard.classList.remove("hidden");
}

async function resetQuiz() {
  tryAgainBtn.disabled = true;
  summaryCard.classList.add("hidden");
  emptyMsg.textContent = "Loading...";

  allQuestions = [];
  await fetchQuestions();
  tryAgainBtn.disabled = false;

  if (allQuestions.length === 0) return;
  showQuestion();
}
