const questionLabel = document.getElementById("question-label");
const questionText = document.getElementById("question-text");
const answersDiv = document.getElementById("answers");
const result = document.getElementById("result");
const nextBtn = document.getElementById("next-btn");
const questionCard = document.getElementById("question-card");
const emptyMsg = document.getElementById("empty-msg");
const progressEl = document.getElementById("progress");
const progressText = document.getElementById("progress-text");
const scoreText = document.getElementById("score-text");
const categorySelect = document.getElementById("filter-category");

let answered = false;
let asked = 0;
let score = 0;

nextBtn.addEventListener("click", handleNext);
categorySelect.addEventListener("focus", refreshCategoryOptions);
refreshCategoryOptions();

// Pull the current filter selections from the form and turn them into a
// querystring for /question. Empty values mean "no filter".
function currentFilters() {
  const params = new URLSearchParams();
  if (categorySelect.value) params.set("category", categorySelect.value);
  const diff = document.querySelector(
    'input[name="filter-difficulty"]:checked',
  );
  if (diff && diff.value) params.set("difficulty", diff.value);
  params.set("limit", "1");
  return params.toString();
}

// Refresh the category <select> options from the server. Called on load and
// whenever the user opens the dropdown, so the list always reflects what's in
// the database (the system of record).
async function refreshCategoryOptions() {
  try {
    const categories = await fetchCategories();
    const names = uniqueCategoryNames(categories);
    const current = categorySelect.value;
    categorySelect.innerHTML =
      `<option value="">Any category</option>` +
      names.map((n) => `<option value="${n}">${n}</option>`).join("");
    // Preserve the user's selection if it still exists in the new list.
    if (current && names.includes(current)) categorySelect.value = current;
  } catch (err) {
    console.warn("Could not load categories:", err.message);
  }
}

async function handleNext() {
  await loadNextQuestion();
}

async function loadNextQuestion() {
  emptyMsg.textContent = "Loading...";
  emptyMsg.classList.remove("hidden");
  questionCard.classList.add("hidden");
  nextBtn.disabled = true;

  let data;
  try {
    const res = await fetch(`/question?${currentFilters()}`);
    if (res.status === 404) {
      emptyMsg.textContent =
        "No questions match these filters — try changing them, or go create some.";
      nextBtn.disabled = false;
      nextBtn.textContent = "Try Again";
      return;
    }
    data = await res.json();
  } catch {
    emptyMsg.textContent = "Could not reach the server.";
    nextBtn.disabled = false;
    return;
  }

  const question = data.questions && data.questions[0];
  if (!question) {
    emptyMsg.textContent = "No question returned by the server.";
    nextBtn.disabled = false;
    return;
  }

  showQuestion(question);
}

function showQuestion(q) {
  answered = false;
  result.classList.add("hidden");
  answersDiv.innerHTML = "";
  emptyMsg.textContent = "";
  emptyMsg.classList.add("hidden");

  // "Easy question on Sport" — single line that anchors the user to the
  // category/difficulty the server actually picked for this round.
  const difficultyLabel =
    q.difficulty.charAt(0).toUpperCase() + q.difficulty.slice(1);
  questionLabel.textContent = `${difficultyLabel} question on ${q.category}`;

  questionText.textContent = q.question;
  q.answers.forEach((text) => {
    const btn = document.createElement("button");
    btn.className = "answer-btn";
    btn.textContent = text;
    btn.addEventListener("click", () => selectAnswer(text, q.correctAnswer));
    answersDiv.appendChild(btn);
  });

  progressEl.classList.remove("hidden");
  updateProgress();

  questionCard.classList.remove("hidden");
  nextBtn.classList.remove("hidden");
  nextBtn.disabled = true;
  nextBtn.textContent = "Next Question";
}

function selectAnswer(selected, correctAnswer) {
  if (answered) return;
  answered = true;
  asked++;

  const buttons = answersDiv.querySelectorAll(".answer-btn");
  buttons.forEach((btn) => {
    btn.disabled = true;
    if (btn.textContent === correctAnswer) btn.classList.add("correct");
    if (btn.textContent === selected && selected !== correctAnswer) {
      btn.classList.add("wrong");
    }
  });

  if (selected === correctAnswer) {
    score++;
    result.textContent = "Correct!";
    result.className = "result correct-text";
  } else {
    result.textContent = `Wrong — the correct answer was "${correctAnswer}".`;
    result.className = "result wrong-text";
  }
  result.classList.remove("hidden");
  nextBtn.disabled = false;
  updateProgress();
}

function updateProgress() {
  progressText.textContent = `Answered: ${asked}`;
  scoreText.textContent = `Score: ${score}`;
}
