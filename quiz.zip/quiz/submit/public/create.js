// ---------- Single-question form ----------

const form = document.getElementById("question-form");
const feedback = document.getElementById("feedback");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  feedback.classList.add("hidden");

  const question = document.getElementById("question").value.trim();
  const answers = [0, 1, 2, 3].map((i) =>
    document.getElementById(`answer-${i}`).value.trim()
  );
  const correctRadio = document.querySelector('input[name="correct"]:checked');

  if (!question) return showError(feedback, "Please enter a question.");
  if (answers.some((a) => !a))
    return showError(feedback, "Please fill in all four answers.");
  if (!correctRadio)
    return showError(feedback, "Please select the correct answer.");

  const correctIndex = parseInt(correctRadio.value, 10);

  try {
    const res = await fetch("/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question, answers, correctIndex }),
    });

    const data = await res.json();

    if (!res.ok) {
      showError(feedback, data.error || "Something went wrong.");
      return;
    }

    showSuccess(
      feedback,
      `Question saved! Total questions: ${data.total ?? "?"}`
    );
    form.reset();
  } catch {
    showError(feedback, "Could not reach the server.");
  }
});

// ---------- Bulk CSV upload ----------

const uploadForm = document.getElementById("upload-form");
const uploadFeedback = document.getElementById("upload-feedback");
const csvInput = document.getElementById("csv-file");

uploadForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  uploadFeedback.classList.add("hidden");

  const file = csvInput.files[0];
  if (!file) return showError(uploadFeedback, "Please choose a CSV file.");

  const data = new FormData();
  data.append("file", file);

  try {
    const res = await fetch("/upload", { method: "POST", body: data });
    const body = await res.json().catch(() => ({}));

    if (!res.ok) {
      const detail = Array.isArray(body.details)
        ? ` (${body.details.slice(0, 3).join("; ")}${
            body.details.length > 3 ? "..." : ""
          })`
        : "";
      showError(uploadFeedback, `${body.error || "Upload failed."}${detail}`);
      return;
    }

    showSuccess(
      uploadFeedback,
      `Uploaded ${body.inserted ?? "?"} question(s). Total: ${body.total ?? "?"}.`
    );
    uploadForm.reset();
  } catch {
    showError(uploadFeedback, "Could not reach the server.");
  }
});

// ---------- Shared feedback helpers ----------

function showError(target, msg) {
  target.textContent = msg;
  target.className = "feedback error";
}

function showSuccess(target, msg) {
  target.textContent = msg;
  target.className = "feedback success";
}
