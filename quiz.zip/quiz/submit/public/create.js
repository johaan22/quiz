// ---------- Single-question form ----------

const form = document.getElementById("question-form");
const feedback = document.getElementById("feedback");
const categoryInput = document.getElementById("category");
const categoryOptions = document.getElementById("category-options");

// Refresh the datalist from the server. Called on load and whenever the user
// focuses the category input, so the dropdown always reflects what's actually
// in the database (the system of record).
async function refreshCategoryOptions() {
  try {
    const categories = await fetchCategories();
    const names = uniqueCategoryNames(categories);
    categoryOptions.innerHTML = names
      .map((n) => `<option value="${n}"></option>`)
      .join("");
  } catch (err) {
    // Non-fatal: the user can still type a new category by hand.
    console.warn("Could not load categories:", err.message);
  }
}

categoryInput.addEventListener("focus", refreshCategoryOptions);
refreshCategoryOptions();

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  feedback.classList.add("hidden");

  const question = document.getElementById("question").value.trim();
  const category = categoryInput.value.trim();
  const difficultyRadio = document.querySelector(
    'input[name="difficulty"]:checked',
  );
  const answers = [0, 1, 2, 3].map((i) =>
    document.getElementById(`answer-${i}`).value.trim(),
  );
  const correctRadio = document.querySelector('input[name="correct"]:checked');

  if (!question) return showError(feedback, "Please enter a question.");
  if (!category) return showError(feedback, "Please choose a category.");
  if (!difficultyRadio)
    return showError(feedback, "Please choose a difficulty.");
  if (answers.some((a) => !a))
    return showError(feedback, "Please fill in all four answers.");
  if (!correctRadio)
    return showError(feedback, "Please select the correct answer.");

  const correctIndex = parseInt(correctRadio.value, 10);
  const difficulty = difficultyRadio.value;

  try {
    const res = await fetch("/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        question,
        answers,
        correctIndex,
        category,
        difficulty,
      }),
    });

    const data = await res.json();

    if (!res.ok) {
      showError(feedback, data.error || "Something went wrong.");
      return;
    }

    showSuccess(
      feedback,
      `Question saved! Total questions: ${data.total ?? "?"}`,
    );
    form.reset();
    // The new question may have introduced a brand-new category — pull the
    // updated list so it shows up in the dropdown straight away.
    refreshCategoryOptions();
  } catch {
    showError(feedback, "Could not reach the server.");
  }
});

// ---------- Bulk CSV upload ----------

const uploadForm = document.getElementById("upload-form");
const uploadFeedback = document.getElementById("upload-feedback");
const csvInput = document.getElementById("csv-file");

uploadForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  uploadFeedback.classList.add("hidden");

  const file = csvInput.files[0];
  if (!file) return showError(uploadFeedback, "Please choose a CSV file.");

  const data = new FormData();
  data.append("file", file);

  try {
    const res = await fetch("/upload", { method: "POST", body: data });
    const body = await res.json().catch(() => ({}));

    if (!res.ok) {
      const detail = Array.isArray(body.details)
        ? ` (${body.details.slice(0, 3).join("; ")}${
            body.details.length > 3 ? "..." : ""
          })`
        : "";
      showError(uploadFeedback, `${body.error || "Upload failed."}${detail}`);
      return;
    }

    showSuccess(
      uploadFeedback,
      `Uploaded ${body.inserted ?? "?"} question(s). Total: ${body.total ?? "?"}.`,
    );
    uploadForm.reset();
    refreshCategoryOptions();
  } catch {
    showError(uploadFeedback, "Could not reach the server.");
  }
});

// ---------- Shared feedback helpers ----------

function showError(target, msg) {
  target.textContent = msg;
  target.className = "feedback error";
}

function showSuccess(target, msg) {
  target.textContent = msg;
  target.className = "feedback success";
}
