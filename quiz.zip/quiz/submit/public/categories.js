// Shared helper used by both the create and quiz pages.
// Single source of truth for talking to GET /categories on the submit service
// (which proxies the question microservice).
async function fetchCategories() {
  const res = await fetch("/categories");
  if (!res.ok) throw new Error(`GET /categories failed (${res.status})`);
  const data = await res.json();
  return Array.isArray(data.categories) ? data.categories : [];
}

// Unique, sorted list of category *names*, ignoring difficulty.
function uniqueCategoryNames(categories) {
  const set = new Set(categories.map((c) => c.category));
  return [...set].sort((a, b) => a.localeCompare(b));
}
