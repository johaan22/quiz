const express = require("express");
const multer = require("multer");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3001;

const QUESTION_SERVICE_URL =
  process.env.QUESTION_SERVICE_URL || "http://localhost:3000";

// Bulk uploads come through as multipart/form-data; keep them in memory,
// they're tiny CSVs and we never need to touch the filesystem.
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 2 * 1024 * 1024 },
});

app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

// Parse a single CSV line into trimmed fields, honoring double-quoted fields
// so values that legitimately contain commas (e.g. "Paris, France") still work.
function parseCsvLine(line) {
  const fields = [];
  let cur = "";
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQuotes) {
      if (ch === '"' && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else if (ch === '"') {
        inQuotes = false;
      } else {
        cur += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ",") {
      fields.push(cur.trim());
      cur = "";
    } else {
      cur += ch;
    }
  }
  fields.push(cur.trim());
  return fields;
}

// CSV row shape (5 or 6 fields):
//   question, answer1, answer2, answer3, answer4[, correctIndex (1-4)]
// If the 6th column is omitted, answer1 is assumed correct.
function csvToQuestions(text) {
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  const items = [];
  const errors = [];

  lines.forEach((line, idx) => {
    const lineNo = idx + 1;
    const fields = parseCsvLine(line);

    if (fields.length !== 5 && fields.length !== 6) {
      errors.push(
        `Line ${lineNo}: expected 5 or 6 comma-separated fields, got ${fields.length}.`,
      );
      return;
    }

    const question = fields[0];
    const answers = fields.slice(1, 5);
    let correctIndex = 0;

    if (fields.length === 6) {
      const n = parseInt(fields[5], 10);
      if (!Number.isInteger(n) || n < 1 || n > 4) {
        errors.push(
          `Line ${lineNo}: correct-answer column must be 1-4, got "${fields[5]}".`,
        );
        return;
      }
      correctIndex = n - 1;
    }

    if (!question) {
      errors.push(`Line ${lineNo}: question text is empty.`);
      return;
    }
    if (answers.some((a) => !a)) {
      errors.push(`Line ${lineNo}: one or more answer columns are empty.`);
      return;
    }

    items.push({ question, answers, correctIndex });
  });

  return { items, errors };
}

async function forwardToQuestionSubmit(payload) {
  const upstream = await fetch(`${QUESTION_SERVICE_URL}/submit`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await upstream.json().catch(() => ({}));
  return { status: upstream.status, data };
}

// Single question submission
app.post("/submit", async (req, res) => {
  try {
    const { status, data } = await forwardToQuestionSubmit(req.body);
    res.status(status).json(data);
  } catch (err) {
    console.error("[submit] Failed to reach question service:", err.message);
    res.status(502).json({ error: "Question service unavailable." });
  }
});

// Bulk upload: read CSV file, transform into JSON array and then POST it to the
// question service's /submit endpoint (which accepts a single object or an array).
app.post("/upload", upload.single("file"), async (req, res) => {
  if (!req.file) {
    return res
      .status(400)
      .json({ error: "No file uploaded. Send a 'file' form field." });
  }

  const text = req.file.buffer.toString("utf-8");
  const { items, errors } = csvToQuestions(text);

  if (errors.length > 0) {
    return res
      .status(400)
      .json({ error: "CSV parse failed.", details: errors });
  }
  if (items.length === 0) {
    return res.status(400).json({ error: "No valid questions found in file." });
  }

  try {
    const { status, data } = await forwardToQuestionSubmit(items);
    res.status(status).json(data);
  } catch (err) {
    console.error("[submit] Failed to reach question service:", err.message);
    res.status(502).json({ error: "Question service unavailable." });
  }
});

// Forward quiz reads to the question service so the browser only has to
// talk to the submit app
app.get("/question", async (req, res) => {
  try {
    const upstream = await fetch(`${QUESTION_SERVICE_URL}/question`);
    const data = await upstream.json().catch(() => ({}));
    res.status(upstream.status).json(data);
  } catch (err) {
    console.error("[submit] Failed to reach question service:", err.message);
    res.status(502).json({ error: "Question service unavailable." });
  }
});

app.listen(PORT, () => {
  console.log(`[submit] Service running at http://localhost:${PORT}`);
  console.log(
    `[submit] Forwarding to question service at ${QUESTION_SERVICE_URL}`,
  );
});
