const express = require("express");
const { Pool } = require("pg");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATABASE_URL =
  process.env.DATABASE_URL || "postgres://quiz:quiz@localhost:5432/quiz";

// Postgres is the canonical system of record for questions.
const pool = new Pool({ connectionString: DATABASE_URL });

async function ensureSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS questions (
      id            SERIAL PRIMARY KEY,
      question      TEXT NOT NULL,
      answers       TEXT[] NOT NULL,
      correct_index INTEGER NOT NULL CHECK (correct_index BETWEEN 0 AND 3),
      created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
}

// One-time migration helper: if the table is empty and a legacy questions.json
// exists, copy it into the DB so the existing quiz keeps working on first boot.
// After this, the DB is authoritative and the file is ignored.
async function maybeSeedFromLegacyFile() {
  const { rows } = await pool.query(
    "SELECT COUNT(*)::int AS count FROM questions"
  );
  if (rows[0].count > 0) return;

  const legacyFile = path.join(__dirname, "questions.json");
  if (!fs.existsSync(legacyFile)) return;

  try {
    const data = JSON.parse(fs.readFileSync(legacyFile, "utf-8"));
    if (!Array.isArray(data) || data.length === 0) return;

    const inserted = await insertQuestions(data);
    console.log(
      `[question] One-time migration: seeded ${inserted} question(s) from questions.json into the DB.`
    );
  } catch (err) {
    console.warn("[question] Legacy seed skipped:", err.message);
  }
}

function validateQuestion(q) {
  if (!q || typeof q !== "object") return "missing question object";
  const { question, answers, correctIndex } = q;
  if (typeof question !== "string" || !question.trim())
    return "question text is required";
  if (!Array.isArray(answers) || answers.length !== 4)
    return "answers must be an array of 4 strings";
  if (answers.some((a) => typeof a !== "string" || !a.trim()))
    return "all answers must be non-empty strings";
  if (!Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex > 3)
    return "correctIndex must be an integer 0-3";
  return null;
}

async function insertQuestions(items) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    for (const q of items) {
      await client.query(
        "INSERT INTO questions (question, answers, correct_index) VALUES ($1, $2, $3)",
        [
          q.question.trim(),
          q.answers.map((a) => a.trim()),
          q.correctIndex,
        ]
      );
    }
    await client.query("COMMIT");
    return items.length;
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

app.use(express.json({ limit: "2mb" }));

// POST /submit — accepts a single question object OR an array of question
// objects (bulk upload). Both shapes go through the same validation & insert.
app.post("/submit", async (req, res) => {
  const body = req.body;
  const items = Array.isArray(body) ? body : [body];

  if (items.length === 0) {
    return res.status(400).json({ error: "No questions provided." });
  }

  for (let i = 0; i < items.length; i++) {
    const err = validateQuestion(items[i]);
    if (err) {
      return res
        .status(400)
        .json({ error: `Invalid question at index ${i}: ${err}` });
    }
  }

  try {
    const inserted = await insertQuestions(items);
    const { rows } = await pool.query(
      "SELECT COUNT(*)::int AS count FROM questions"
    );
    res.json({
      message: `Saved ${inserted} question(s).`,
      inserted,
      total: rows[0].count,
    });
  } catch (err) {
    console.error("[question] /submit failed:", err);
    res.status(500).json({ error: "Failed to save question(s)." });
  }
});

// GET /question — return all questions (random order) sourced from the DB.
app.get("/question", async (req, res) => {
  try {
    const { rows } = await pool.query(
      "SELECT question, answers, correct_index FROM questions ORDER BY random()"
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: "No questions available." });
    }

    const payload = rows.map((r) => ({
      question: r.question,
      answers: r.answers,
      correctAnswer: r.answers[r.correct_index],
    }));

    res.json({ questions: payload, total: rows.length });
  } catch (err) {
    console.error("[question] /question failed:", err);
    res.status(500).json({ error: "Failed to read questions." });
  }
});

// Postgres may not be ready the instant this container starts even with
// healthchecks (e.g. local dev outside compose). Retry the initial connect.
async function start() {
  const maxAttempts = 10;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      await ensureSchema();
      await maybeSeedFromLegacyFile();
      break;
    } catch (err) {
      if (attempt === maxAttempts) throw err;
      console.warn(
        `[question] DB not ready (${err.code || err.message}); attempt ${attempt}/${maxAttempts}, retrying in 2s...`
      );
      await new Promise((r) => setTimeout(r, 2000));
    }
  }

  app.listen(PORT, () => {
    console.log(`[question] Service running at http://localhost:${PORT}`);
    console.log(`[question] Using DB at ${DATABASE_URL.replace(/:[^:@/]+@/, ":***@")}`);
  });
}

start().catch((err) => {
  console.error("[question] Fatal startup error:", err);
  process.exit(1);
});
