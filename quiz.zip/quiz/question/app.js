const express = require("express");
const { Pool } = require("pg");

const app = express();
const PORT = process.env.PORT || 3000;
const DATABASE_URL =
  process.env.DATABASE_URL || "postgres://quiz:quiz@localhost:5432/quiz";

// Postgres is the canonical system of record for questions and categories.
const pool = new Pool({ connectionString: DATABASE_URL });

const DIFFICULTIES = ["easy", "hard"];

async function ensureSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS categories (
      id         SERIAL PRIMARY KEY,
      category   TEXT NOT NULL,
      difficulty TEXT NOT NULL CHECK (difficulty IN ('easy', 'hard')),
      UNIQUE (category, difficulty)
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS questions (
      id            SERIAL PRIMARY KEY,
      question      TEXT NOT NULL,
      answers       TEXT[] NOT NULL,
      correct_index INTEGER NOT NULL CHECK (correct_index BETWEEN 0 AND 3),
      category_id   INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
      created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  await migrateAddCategoryFK();
}

// Bring an older `questions` table (without category_id)
async function migrateAddCategoryFK() {
  await pool.query(
    "ALTER TABLE questions ADD COLUMN IF NOT EXISTS category_id INTEGER",
  );

  // There is no `ADD CONSTRAINT IF NOT EXISTS`, so look it up in the catalog.
  await pool.query(`
    DO $$
    BEGIN
      IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'questions_category_id_fkey'
      ) THEN
        ALTER TABLE questions
          ADD CONSTRAINT questions_category_id_fkey
          FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT;
      END IF;
    END $$;
  `);

  const { rows } = await pool.query(
    "SELECT COUNT(*)::int AS n FROM questions WHERE category_id IS NULL",
  );
  if (rows[0].n > 0) {
    await pool.query(`
      INSERT INTO categories (category, difficulty)
      VALUES ('Uncategorised', 'easy')
      ON CONFLICT (category, difficulty) DO NOTHING
    `);
    await pool.query(`
      UPDATE questions SET category_id = (
        SELECT id FROM categories WHERE category = 'Uncategorised' AND difficulty = 'easy'
      )
      WHERE category_id IS NULL
    `);
  }

  await pool.query(
    "ALTER TABLE questions ALTER COLUMN category_id SET NOT NULL",
  );
}

function normalizeCategory(s) {
  // so "  sport " and "Sport"
  // maps to the same row in the categories table.
  return s
    .trim()
    .replace(/\s+/g, " ")
    .toLowerCase()
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function validateQuestion(q) {
  if (!q || typeof q !== "object") return "missing question object";
  const { question, answers, correctIndex, category, difficulty } = q;
  if (typeof question !== "string" || !question.trim())
    return "question text is required";
  if (!Array.isArray(answers) || answers.length !== 4)
    return "answers must be an array of 4 strings";
  if (answers.some((a) => typeof a !== "string" || !a.trim()))
    return "all answers must be non-empty strings";
  if (!Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex > 3)
    return "correctIndex must be an integer 0-3";
  if (typeof category !== "string" || !category.trim())
    return "category is required";
  if (typeof difficulty !== "string" || !DIFFICULTIES.includes(difficulty))
    return `difficulty must be one of: ${DIFFICULTIES.join(", ")}`;
  return null;
}

async function findOrCreateCategoryId(client, category, difficulty) {
  const name = normalizeCategory(category);
  await client.query(
    `INSERT INTO categories (category, difficulty)
     VALUES ($1, $2)
     ON CONFLICT (category, difficulty) DO NOTHING`,
    [name, difficulty],
  );
  const { rows } = await client.query(
    "SELECT id FROM categories WHERE category = $1 AND difficulty = $2",
    [name, difficulty],
  );
  return rows[0].id;
}

async function insertQuestions(items) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    for (const q of items) {
      const categoryId = await findOrCreateCategoryId(
        client,
        q.category,
        q.difficulty,
      );
      await client.query(
        `INSERT INTO questions (question, answers, correct_index, category_id)
         VALUES ($1, $2, $3, $4)`,
        [
          q.question.trim(),
          q.answers.map((a) => a.trim()),
          q.correctIndex,
          categoryId,
        ],
      );
    }
    await client.query("COMMIT");
    return items.length;
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

app.use(express.json({ limit: "2mb" }));

// GET /categories — list every (category, difficulty) pair the system knows about
app.get("/categories", async (_req, res) => {
  try {
    const { rows } = await pool.query(
      "SELECT id, category, difficulty FROM categories ORDER BY category, difficulty",
    );
    res.json({ categories: rows });
  } catch (err) {
    console.error("[question] /categories failed:", err);
    res.status(500).json({ error: "Failed to read categories." });
  }
});

// POST /submit — accepts a single question object OR an array of questions
app.post("/submit", async (req, res) => {
  const body = req.body;
  const items = Array.isArray(body) ? body : [body];

  if (items.length === 0) {
    return res.status(400).json({ error: "No questions provided." });
  }

  for (let i = 0; i < items.length; i++) {
    const err = validateQuestion(items[i]);
    if (err) {
      return res
        .status(400)
        .json({ error: `Invalid question at index ${i}: ${err}` });
    }
  }

  try {
    const inserted = await insertQuestions(items);
    const { rows } = await pool.query(
      "SELECT COUNT(*)::int AS count FROM questions",
    );
    res.json({
      message: `Saved ${inserted} question(s).`,
      inserted,
      total: rows[0].count,
    });
  } catch (err) {
    console.error("[question] /submit failed:", err);
    res.status(500).json({ error: "Failed to save question(s)." });
  }
});

// GET /question — return questions in random order
app.get("/question", async (req, res) => {
  const { category, difficulty, limit } = req.query;

  const where = [];
  const params = [];

  if (typeof category === "string" && category.trim()) {
    params.push(normalizeCategory(category));
    where.push(`c.category = $${params.length}`);
  }
  if (typeof difficulty === "string" && difficulty.trim()) {
    if (!DIFFICULTIES.includes(difficulty)) {
      return res.status(400).json({
        error: `difficulty must be one of: ${DIFFICULTIES.join(", ")}`,
      });
    }
    params.push(difficulty);
    where.push(`c.difficulty = $${params.length}`);
  }

  let sql = `
    SELECT q.question, q.answers, q.correct_index, c.category, c.difficulty
    FROM questions q
    JOIN categories c ON c.id = q.category_id
  `;
  if (where.length) sql += ` WHERE ${where.join(" AND ")}`;
  sql += " ORDER BY random()";

  if (limit !== undefined) {
    const n = parseInt(limit, 10);
    if (!Number.isInteger(n) || n < 1) {
      return res
        .status(400)
        .json({ error: "limit must be a positive integer" });
    }
    params.push(n);
    sql += ` LIMIT $${params.length}`;
  }

  try {
    const { rows } = await pool.query(sql, params);

    if (rows.length === 0) {
      return res.status(404).json({ error: "No questions available." });
    }

    const payload = rows.map((r) => ({
      question: r.question,
      answers: r.answers,
      correctAnswer: r.answers[r.correct_index],
      category: r.category,
      difficulty: r.difficulty,
    }));

    res.json({ questions: payload, total: rows.length });
  } catch (err) {
    console.error("[question] /question failed:", err);
    res.status(500).json({ error: "Failed to read questions." });
  }
});

// Postgres may not be ready the instant this container starts even with
async function start() {
  const maxAttempts = 10;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      await ensureSchema();
      break;
    } catch (err) {
      if (attempt === maxAttempts) throw err;
      console.warn(
        `[question] DB not ready (${err.code || err.message}); attempt ${attempt}/${maxAttempts}, retrying in 2s...`,
      );
      await new Promise((r) => setTimeout(r, 2000));
    }
  }

  app.listen(PORT, () => {
    console.log(`[question] Service running at http://localhost:${PORT}`);
    console.log(
      `[question] Using DB at ${DATABASE_URL.replace(/:[^:@/]+@/, ":***@")}`,
    );
  });
}

start().catch((err) => {
  console.error("[question] Fatal startup error:", err);
  process.exit(1);
});
